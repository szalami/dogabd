# Költség kezelő program

Refaktorálásra szánt.

Refaktoráláskor nevezd át okcost-ra. Ír le a fejrészbe, ki vagy te, és mikor csinálod.
