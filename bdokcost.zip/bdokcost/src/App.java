/*
 * Sallai András, 2024-02-19
 * Copyright (c) 2024, Sallai András
 * Licenc: MIT
 * Refaktorálás: Béres Délia, 2024-02-26
 */

public class App {
    public static void main(String[] args) throws Exception {
        new MainConsole();
    }
}
