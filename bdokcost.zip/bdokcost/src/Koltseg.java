/*
 * Sallai András, 2024-02-19
 * Copyright (c) 2024, Sallai András
 * Licenc: MIT
 * Refaktorálás: Béres Délia, 2024-02-26
 */

public class Koltseg {

    Double szallitas;
    Double uzlet;
    Double javitas;

    public Koltseg() {
    };

    public Koltseg(Double szallitas, Double uzlet, Double javitas) {
        this.szallitas = szallitas;
        this.uzlet = uzlet;
        this.javitas = javitas;
    }

}
